## *432 = *mk2
F:=FreeGroup(3);  t1:=F.1;; t2:=F.2;; t3:=F.3;;
rels:=[t1^2,t2^2,t3^2,(t1*t3)^3,(t1*t2)^4,(t2*t3)^2];;
g:=F/rels;;
t1:=g.1;; t2:=g.2;; t3:=g.3;;
g1:=Subgroup(g,[t1]);;
g2:=Subgroup(g,[t2]);;
g3:=Subgroup(g,[t2,t3]);;
g4:=Subgroup(g,[t1,t3]);;
g5:=Subgroup(g,[t1,t2]);;
cs1:=RightCosets(g,g1);;
cs2:=RightCosets(g,g2);;
cs3:=RightCosets(g,g3);;
cs4:=RightCosets(g,g4);;
cs5:=RightCosets(g,g5);;
G1:=Action(g,cs1,OnRight);;
G2:=Action(g,cs2,OnRight);;
G3:=Action(g,cs3,OnRight);;
G4:=Action(g,cs4,OnRight);;
G5:=Action(g,cs5,OnRight);;

