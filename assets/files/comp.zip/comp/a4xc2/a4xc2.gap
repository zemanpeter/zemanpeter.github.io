## 3*2
F:=FreeGroup(3);  r:=F.1;; t:=F.2;; z:=F.3;;
rels:=[r^3,t^2,(r*t)^3,z^2,z*r*z*r^(-1),z*t*z*t^(-1)];;
g:=F/rels;;
r:=g.1;; t:=g.2;; z:=g.3;;
g1:=Subgroup(g,[z]);;
g2:=Subgroup(g,[r]);;
g3:=Subgroup(g,[z,t]);;
cs1:=RightCosets(g,g1);;
cs2:=RightCosets(g,g2);;
cs3:=RightCosets(g,g3);;
G1:=Action(g,cs1,OnRight);;
G2:=Action(g,cs2,OnRight);;
G3:=Action(g,cs3,OnRight);; 