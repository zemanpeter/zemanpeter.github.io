┌───────┐   GAP 4.11.1 of 2021-03-02
 │  GAP  │   https://www.gap-system.org
 └───────┘   Architecture: x86_64-pc-cygwin-default64-kv7
 Configuration:  gmp 6.2.0, GASMAN, readline
 Loading the library and packages ...
 Packages:   AClib 1.3.2, Alnuth 3.1.2, AtlasRep 2.1.0, AutoDoc 2020.08.11, AutPGrp 1.10.2, Browse 1.8.11,
             CaratInterface 2.3.3, CRISP 1.4.5, Cryst 4.1.23, CrystCat 1.1.9, CTblLib 1.3.1, FactInt 1.6.3, FGA 1.4.0,
             Forms 1.2.5, GAPDoc 1.6.4, genss 1.6.6, IO 4.7.0, IRREDSOL 1.4.1, LAGUNA 3.9.3, orb 4.8.3, Polenta 1.3.9,
             Polycyclic 2.16, PrimGrp 3.4.1, RadiRoot 2.8, recog 1.3.2, ResClasses 4.7.2, SmallGrp 1.4.2, Sophus 1.24,
             SpinSym 1.5.2, TomLib 1.2.9, TransGrp 3.0, utils 0.69
 Try '??help' for help. See also '?copyright', '?cite' and '?authors'
─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
Loading  singular 2020.12.18 (A GAP interface to Singular)
by Marco Costantini and
   Willem Adriaan de Graaf (https://www.science.unitn.it/~degraaf/).
maintained by:
   The GAP Team (support@gap-system.org).
Homepage: https://gap-packages.github.io/singular/
Report issues at https://github.com/gap-packages/singular/issues
─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
Loading  GRAPE 4.8.3 (GRaph Algorithms using PErmutation groups)
by Leonard H. Soicher (http://www.maths.qmul.ac.uk/~lsoicher/).
Homepage: https://gap-packages.github.io/grape
Report issues at https://github.com/gap-packages/grape/issues
─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
COCO2P: Using Singular for the computation of Groebner-bases...
----------------------------------------------------------------
Loading  COCO2P 0.19
by Mikhail Klin (klin@math.bgu.ac.il)
   Christian Pech (cpech@freenet.de)
   Sven Reichard (sven.reichard@tu-dresden.de)
For help, type: ?COCO2P:
----------------------------------------------------------------
─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
Loading  WLFast 0.8
by Saveliy Skresanov.
Homepage: https://google.com/
─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

gap> Read("d:/_functions.gap");
gap>
gap>
gap> F:=FreeGroup(3);;  t1:=F.1;; t2:=F.2;; t3:=F.3;;
gap> rels:=[t1^2,t2^2,t3^2,(t1*t3)^3,(t1*t2)^5,(t2*t3)^2];;
gap> g:=F/rels;;
gap> t1:=g.1;; t2:=g.2;; t3:=g.3;;
gap> g1:=Subgroup(g,[t1]);;
gap> g2:=Subgroup(g,[t2,t3]);;
gap> g3:=Subgroup(g,[t1,t3]);;
gap> g4:=Subgroup(g,[t1,t2]);;
gap> cs1:=RightCosets(g,g1);;
gap> cs2:=RightCosets(g,g2);;
gap> cs3:=RightCosets(g,g3);;
gap> cs4:=RightCosets(g,g4);;


gap> G:=Action(g,Concatenation(cs2,cs3),OnRight);; c:=ColorGraph(G);
<color graph of order 50 and rank 30>

gap> G:=Action(g,Concatenation(cs2,cs3),OnRight);; c:=ColorGraph(G); StructureDescription(AutomorphismGroup(c));
<color graph of order 50 and rank 30>
"C2 x A5"
gap> List(Fibres(c),x->[Size(x),x[1]]);
[ [ 30, 1 ], [ 20, 31 ] ]
gap>  u:=cnset2(c);; Size(u);
255
gap> Index(ColorAutomorphismGroup(c),AutomorphismGroup(c));
4
gap> t:=StructureConstantsOfColorGraph(c);; at:=AutomorphismGroup(t);; Size(at);
4
gap> o:=Orbits(Action(at,u,OnSets));; ro:=List(o,x->x[1]);;  u1:=List(ro,x->u[x]);; Size(u1);
85
gap> u2:=Filtered(u1,x-> 30 = Rank(CreateFus(c,x)));; Size(u2);
33
gap> wg(c,u2,1,33);
