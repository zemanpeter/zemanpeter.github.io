## 532 = 2km

F:=FreeGroup(2);  r1:=F.1;; r2:=F.2;;
rels:=[r1^3,r2^5,(r1*r2)^2];;
g:=F/rels;;
r1:=g.1;; r2:=g.2;; 
g1:=Subgroup(g,[r1*r2]);;
g2:=Subgroup(g,[r1]);;
g3:=Subgroup(g,[r2]);;
cs1:=RightCosets(g,g1);;
cs2:=RightCosets(g,g2);;
cs3:=RightCosets(g,g3);;
G1:=Action(g,cs1,OnRight);;
G2:=Action(g,cs2,OnRight);;
G3:=Action(g,cs3,OnRight);;
 