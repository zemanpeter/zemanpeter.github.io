## 332
F:=FreeGroup(2);  r1:=F.1;; r2:=F.2;; 
rels:=[r1^3,r2^3,(r1*r2)^2];;
g:=F/rels;;
r1:=g.1;; r2:=g.2;;
g1:=Subgroup(g,[r1*r2]);;
g2:=Subgroup(g,[r1]);;
cs1:=RightCosets(g,g1);;
cs2:=RightCosets(g,g2);;