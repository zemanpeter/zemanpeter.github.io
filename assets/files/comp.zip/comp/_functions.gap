#########################################33

testpoint:=function(L0,c,t,x1,x2,u,w,Prt)
       local a,c1,c2,cu,m,is;
       c1:=ArcColorOfColorGraph(c,x1,u);
	   c2:=ArcColorOfColorGraph(c,u,x2);
	   cu:=ArcColorOfColorGraph(c,x1,x2);
	   a:=ComplexProduct(t,Prt[w[c1]],Prt[w[c2]]);
	   m:=Filtered(Prt[w[cu]],x->a[x]=2);
	   if Size(m)= 0 then return false; fi; 
	   if Size(m)= Size(Prt[w[cu]]) then return true; fi;
	   a:=List(Difference(L0,[x1,x2]),x->cmprs(t,Prt[w[ArcColorOfColorGraph(c,x1,x)]],Prt[w[ArcColorOfColorGraph(c,x,x2)]]));
	   return IsSubset(m,Intersection(a));
end;

## c - color graph,  l - unitial color, Prt - partition of S(c), frb - forbidden colors (reflexive colors and antipodal)
gc1:=function(c,l,Prt,frb)
   local L0,L,P,N,t,n,w;
   n:=Order(c);
   t:=StructureConstantsOfColorGraph(c);
   w:=List([1..Order(t)],x->First([1..Size(Prt)],y->x in Prt[y]));
   L0:=[]; L:=ColorRepresentative(c,l);
   while L <> [] do
       L0:=Union(L0,L);  N:=Difference([1..n],L0);
       P:=Filtered(Cartesian(L0,L0),x-> not (ArcColorOfColorGraph(c,x[1],x[2]) in frb));
	   L:=Set(Union(List(P,x->Filtered(N,y-> testpoint(L0,c,t,x[1],x[2],y,w,Prt)))));
   od;
   return Size(L0)=n;
end;



########################################################################


CreateGraph:=function(c,s)
    local n,A,i; 
    n:=Order(c);	
    A:=NullMat(n,n);
    for i in Cartesian([1..n],[1..n]) do if ArcColorOfColorGraph(c,i[1],i[2]) in s then A[i[1]][i[2]]:=1; fi; od;
    return A;
end;

CreateLapl:=function(c,s)
    local n,A,i;    
    A:=(-1)*CreateGraph(c,s);
	for i in [1..Order(c)] do A[i][i]:=(-1)*Sum(A[i]); od;
    return A;
end;	
	
CreateFus:=function(c,s)	
	local cp;
	cp:=ColorGraphByMatrix(CreateGraph(c,s));
	return WLStabilizationExternal(cp);
end;



typecc:=function(c)
     local f;
	 f:=Fibres(c);
	 return List(f,x->List(f,y->Size(Set(List(y,z->ArcColorOfColorGraph(c,x[1],z))))));
end;

relfb:=function(c,i,j)
      local u,v,s;
      u:=Fibres(c)[i][1]; v:=Fibres(c)[j]; 
      s:=Set(List(v),x->ArcColorOfColorGraph(c,u,x));
	  return List(s,x->[x,Size(Neighbors(c,u,x))]);
end;	  


## representation for graphs to maple; the graphs are defined by subsets of the basis relations of
## a coherent configuration c; these subsets are in the table let

wg:=function(c,l,i,j)
  local a,A,L,b,u;
  AppendTo("d:/os.txt","[\n");
  for a in [i..j-1] do 
      A:=CreateGraph(c,l[a]);;
      L:=Filtered(Cartesian([1..Order(c)],[1..Order(c)]),x->A[x[1]][x[2]]<>0);;
      AppendTo("d:/os.txt","{");
      u:=Size(L);
	  for b in [1..u-1] do  AppendTo("d:/os.txt","{",L[b][1],",",L[b][2],"},"); od;
      AppendTo("d:/os.txt","{",L[u][1],",",L[u][2],"}},\n");
  od; 
  A:=CreateGraph(c,l[j]);;
  L:=Filtered(Cartesian([1..Order(c)],[1..Order(c)]),x->A[x[1]][x[2]]<>0);;
  AppendTo("d:/os.txt","{");
  u:=Size(L);
  for b in [1..u-1] do  AppendTo("d:/os.txt","{",L[b][1],",",L[b][2],"},"); od;
  AppendTo("d:/os.txt","{",L[u][1],",",L[u][2],"}}\n]\n");
end;

cnset1:=function(c)
    local r,n,s;
    r:=ReflexiveColors(c)[1];  n:=Order(c); 
    s:=List(relfb(c,1,1),x->x[1]);
    s:=Difference(s,[r]);; s:=Filtered(Combinations(s),x->Set(x)=Set(OnSets(x,ColorMates(c))));
    return Filtered(s,x-> (3*n-6) >= (Sum(List([1..n],y->Size(Neighbors(c,y,x))))/2));
end;

cnset2:=function(c)
    local r,f,v1,n1,v2,n2,s11,s12,s22,tf,u,u1,u2;
    r:=ReflexiveColors(c); f:=Fibres(c); v1:=f[1][1]; n1:=Size(f[1]); v2:=f[2][1]; n2:=Size(f[2]); 
    s11:=List(relfb(c,1,1),x->x[1]);
    s11:=Difference(s11,[r[1]]);; s11:=Filtered(Combinations(s11),x->Set(x)=Set(OnSets(x,ColorMates(c))));
    s11:=Filtered(s11,x->6 > Size(Neighbors(c,v1,x)));
    s12:=List(relfb(c,1,2),x->x[1]);
	s12:=List(Combinations(s12),x->Set(Union(x,List(x,y->y^ColorMates(c)))));
    s12:=Filtered(s12,x->(n1*Size(Neighbors(c,v1,x))) <= ((n1+n2)*3-6));
    s22:=List(relfb(c,2,2),x->x[1]);
	s22:=Difference(s22,[r[2]]);; s22:=Filtered(Combinations(s22),x->Set(x)=Set(OnSets(x,ColorMates(c))));
    s22:=Filtered(s22,x->6 > Size(Neighbors(c,v2,x)));
	tf:=Cartesian(s22,s12);;  u:=List(tf,x->Union(x[1],x[2]));;
    u1:=Filtered(u,x->Sum(List([1..n1+n2],y->Size(Neighbors(c,y,x))))/2 <= ((n1+n2)*3-6));;
    tf:=Cartesian(u1,s11);;  u2:=List(tf,x->Union(x[1],x[2]));;
    return Filtered(u2,x-> (3*(n1+n2)-6) >= (Sum(List([1..(n1+n2)],y->Size(Neighbors(c,y,x))))/2));
end;

cnset3:=function(c)
    local r,f,v1,n1,v2,n2,v3,n3,s11,s12,s22,s13,s23,s33,tf,u,u1,u2,u3,u4;
    r:=ReflexiveColors(c); f:=Fibres(c); v1:=f[1][1]; n1:=Size(f[1]); v2:=f[2][1]; n2:=Size(f[2]); v3:=f[3][1]; n3:=Size(f[3]); 
    s11:=List(relfb(c,1,1),x->x[1]);
    s11:=Difference(s11,[r[1]]);; s11:=Filtered(Combinations(s11),x->Set(x)=Set(OnSets(x,ColorMates(c))));
    s11:=Filtered(s11,x->6 > Size(Neighbors(c,v1,x)));
    s12:=List(relfb(c,1,2),x->x[1]);
	s12:=List(Combinations(s12),x->Set(Union(x,List(x,y->y^ColorMates(c)))));
    s12:=Filtered(s12,x->(n1*Size(Neighbors(c,v1,x))) <= ((n1+n2)*3-6));
    s22:=List(relfb(c,2,2),x->x[1]);
	s22:=Difference(s22,[r[2]]);; s22:=Filtered(Combinations(s22),x->Set(x)=Set(OnSets(x,ColorMates(c))));
    s22:=Filtered(s22,x->6 > Size(Neighbors(c,v2,x)));
	tf:=Cartesian(s22,s12);;  u:=List(tf,x->Union(x[1],x[2]));;
    u1:=Filtered(u,x->Sum(List([1..n1+n2],y->Size(Neighbors(c,y,x))))/2 <= ((n1+n2)*3-6));;
    tf:=Cartesian(u1,s11);;  u2:=List(tf,x->Union(x[1],x[2]));;
    u3:=Filtered(u2,x-> (3*(n1+n2)-6) >= (Sum(List([1..(n1+n2)],y->Size(Neighbors(c,y,x))))/2));
    s13:=List(relfb(c,1,3),x->x[1]);
	s13:=List(Combinations(s13),x->Set(Union(x,List(x,y->y^ColorMates(c)))));
    s13:=Filtered(s13,x->(n1*Size(Neighbors(c,v1,x))) <= ((n1+n3)*3-6));
    s23:=List(relfb(c,2,3),x->x[1]);
	s23:=List(Combinations(s23),x->Set(Union(x,List(x,y->y^ColorMates(c)))));
    s23:=Filtered(s23,x->(n2*Size(Neighbors(c,v2,x))) <= ((n2+n3)*3-6));
    s33:=List(relfb(c,3,3),x->x[1]);
	s33:=Difference(s33,[r[3]]);; s33:=Filtered(Combinations(s33),x->Set(x)=Set(OnSets(x,ColorMates(c))));
    s33:=Filtered(s33,x->6 > Size(Neighbors(c,v3,x)));
	tf:=Cartesian(u3,s13);;    u:=List(tf,x->Union(x[1],x[2]));;
    u1:=Filtered(u,x->Sum(List([1..n1+n2+n3],y->Size(Neighbors(c,y,x))))/2 <= ((n1+n2+n3)*3-6));;
    tf:=Cartesian(u1,s23);;  u2:=List(tf,x->Union(x[1],x[2]));;
    u3:=Filtered(u2,x-> (3*(n1+n2+n3)-6) >= (Sum(List([1..(n1+n2+n3)],y->Size(Neighbors(c,y,x))))/2));
    tf:=Cartesian(u3,s33);;  u4:=List(tf,x->Union(x[1],x[2]));;
    return Filtered(u4,x-> (3*(n1+n2+n3)-6) >= (Sum(List([1..(n1+n2+n3)],y->Size(Neighbors(c,y,x))))/2));
end;

DoubleOrbit:=function(G,D)
   local U,f;
   U:=Union(List([1..NrMovedPoints(G)],x->[x,1]),List(D,x->[x,2]));;
   f:=function(x,g) return [x[1]^g,x[2]]; end;
   return Action(G,U,f);
end;



mpfsn:=function(c,i,mp)
   return List(mp,x->Set(List(x,y->ArcColorOfColorGraph(c,i,y))));
end;
   





